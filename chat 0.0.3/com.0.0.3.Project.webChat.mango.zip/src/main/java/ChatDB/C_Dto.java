package ChatDB;

public class C_Dto {

	public String userNo;
	public String chat;
	public String time;
	

	public C_Dto(String userNo, String chat, String time) {
		this.userNo = userNo;
		this.chat = chat;
		this.time = time;
	}

	
	
}

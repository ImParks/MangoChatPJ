package com.Jsp.Board.BoardDB;

public class Db {

	public static final String DB_LINK =  "com.mysql.cj.jdbc.Driver";
	public static final String DB_NAME = "board";
	public static final String DB_SQL_URL = "jdbc:mysql://localhost:3306/" + DB_NAME;
	public static final String DB_URL = DB_SQL_URL;
	public static final String DB_ID = "root";
	public static final String DB_PW = "root";
	public static final String DB_MEMBER = "member";
	public static final String DB_BOARD = "board";
	
}

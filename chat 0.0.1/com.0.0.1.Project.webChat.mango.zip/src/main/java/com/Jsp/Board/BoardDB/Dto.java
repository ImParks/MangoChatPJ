package com.Jsp.Board.BoardDB;

public class Dto {
	public String no;
	public String title;
	public String time;
	public String name;
	public String hit;
	public String text;
	public String num;
	
	public Dto(String title,String text,String name,String num) {
		this.title = title;
		this.text = text;
		this.name = name;
		this.num = num;
	}
	
	public Dto(String title,String text) {
		this.title = title;
		this.text = text;
	}
	
	Dto(String no, String title, String time, String name,String num, String hit) {
		this.no = no;
		this.title = title;
		this.time = time;
		this.name = name;
		this.num = num;
		this.hit = hit;
	}

	Dto(String no, String title, String time, String name,String num, String hit, String text) {
		this.no = no;
		this.title = title;
		this.time = time;
		this.name = name;
		this.num = num;
		this.hit = hit;
		this.text = text;

	}

}

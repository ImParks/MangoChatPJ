package com.MangoChat.ChatDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.MangoChat.MasterClass.Master_DA;
import com.MangoChat.MasterClass.Master_DB;

public class C_Dao extends Master_DA {

	public ArrayList<C_Dto> chattingList(String roomNo) {
		ArrayList<C_Dto> list = new ArrayList<C_Dto>();
		String sql = String.format("SELECT * FROM %s WHERE roomNo = %s",Master_DB.DB_TABLE_CHATTING,roomNo);
		try {
			ResultSet rs = super.Query(sql);
			while (rs.next()) {
				list.add(new C_Dto(rs.getString("userNo"), rs.getString("chat"),rs.getString("time")));
			}
		} catch (Exception e) {
			System.out.println(sql);
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}

	
	public String name(String userNo,String query) {
		String a = null;
		String sql = String.format("SELECT * FROM %s WHERE userNo = %s",Master_DB.DB_TABLE_CHATTING,userNo);
		try {
			ResultSet rs = super.Query(sql);
			rs.next();
			a = rs.getString(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return a;
	}

	public void chatting(String roomNo, String chat,String userNo) {
		String sql = String.format("INSERT INTO %s(roomNo,userNo,chat)VALUES(%s,%s,'%s')",Master_DB.DB_TABLE_CHATTING,roomNo,userNo,chat);
		try {
			super.update(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close();
		}
	}
	
	public String chatName(String no) {
		String name = null;
		String sql = String.format("SELECT * FROM %s WHERE userNo = %s",Master_DB.DB_TABLE_LOGIN,no);
		try {

			ResultSet rs = super.Query(sql);
			rs.next();
			name = rs.getString("userName");
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return name;
	}
	public String chatTag(String no) {
		String tag = null;
		try {
			String sql = String.format("SELECT * FROM %s WHERE userNo = "+no,Master_DB.DB_TABLE_LOGIN);
			ResultSet rs = super.Query(sql);
			rs.next();
			tag = String.format(rs.getString("userTag"));
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return tag;
	}
}

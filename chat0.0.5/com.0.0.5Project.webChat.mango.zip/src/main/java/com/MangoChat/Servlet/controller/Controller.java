package com.MangoChat.Servlet.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MangoChat.LoginDB.L_Dto;
import com.MangoChat.Servlet.Service;

@WebServlet("/chat/*")
public class Controller extends HttpServlet {

	Service service;
	String nextPage;
	String id;
	String pw;

	public void init() throws ServletException {
		service = new Service();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		request.setCharacterEncoding("UTF-8");
		String action = request.getPathInfo();
		if (action != null) {
			switch (action) {
			case "/signUp":
				nextPage = "/signUp.jsp";
				break;
			case "/signUp_proc":
				id = String.format(request.getParameter("id"));
				pw = String.format(request.getParameter("pw"));
				String pwRe = String.format(request.getParameter("pwRe"));
				String name = String.format(request.getParameter("name"));
				String regex = ".*[\\p{Punct}\\s].*";
				try {
				if (id.length() <= 0 || pw.length() <= 0 || pwRe.length() <= 0 || name.length() <= 0) {
					nextPage = "/signUp.jsp?mag=null";
				} else if (id.matches(regex) || pw.matches(regex) || pwRe.matches(regex) || name.matches(regex)) {
					nextPage = "/signUp.jsp?mag=*";
				} else if (!pw.equals(pwRe)) {
					nextPage = "/signUp.jsp?mag=pw";
				} else if (service.signUpIdCk(id)) {
					L_Dto join = new L_Dto(id, pw, name);
					service.signUp(join);
					nextPage = "/chat/login";
				} else {
					nextPage = "/signUp.jsp?mag=id";
				}
				}catch (NullPointerException e){
					session.setAttribute("mag", "null");
					nextPage = "/signUp.jsp?mag=null";
				}
				break;
			case "/login_proc":
				id = String.format(request.getParameter("id"));
				pw = String.format(request.getParameter("pw"));
				System.out.println(id);
				if (service.idck(id,pw)) {
					L_Dto idPw = service.idPw(id,pw);
					session.setAttribute("userNo", idPw.userNo);
					System.out.println(idPw.userNo);
					session.setAttribute("userName", idPw.userName);
					session.setAttribute("userTag", idPw.userTag);
					nextPage = "/index.jsp";
				} else {
					nextPage = "/chat/login";
				}
				break;
			case "/chatting":
				nextPage = "/chat/index";
				String chat = request.getParameter("chat");
				String roomNo = request.getParameter("roomNo");
				String userNo = (String) session.getAttribute("userNo");
				service.chatting(roomNo, chat, userNo);
				break;
			case "/index":
				nextPage = "/index.jsp";
				request.setAttribute("roomNo", request.getParameter("roomNo"));
				break;
			case "/login":
				response.sendRedirect("login.jsp");
				break;
			}

			RequestDispatcher n = request.getRequestDispatcher(nextPage);
			n.forward(request, response);
		}

	}
}

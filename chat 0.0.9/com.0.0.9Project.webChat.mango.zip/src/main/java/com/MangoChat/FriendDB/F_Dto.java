package com.MangoChat.FriendDB;

public class F_Dto {
	
	public String myUserNo;
	public String friendUserNo;
	public String time;
	
	public F_Dto(String myUserNo,String friendUserNo, String time) {
			this.myUserNo = myUserNo;
			this.friendUserNo = friendUserNo;
			this.time = time;
	}
	
	
}

package com.MangoChat.FriendDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.MangoChat.MasterClass.Master_DA;
import com.MangoChat.MasterClass.Master_DB;

public class F_Dao extends Master_DA {

	public ArrayList<String> friendList(String myUserNo) {
		ArrayList<String> list = new ArrayList<>();
		String sql = String.format("SELECT * FROM %s WHERE myUserNo = %s", DB_TABLE_LIST, myUserNo);
		try {
			ResultSet rs = Query(sql);
			while (rs.next()) {
				list.add(rs.getString("friendUserNo"));
			}
		} catch (SQLException e) {
			System.out.println(sql);
			e.printStackTrace();
		}finally {
			close();
		}
		return list;
	}
	
	//친구 삭제 실행문
	public void friendDel(String myNo, String friendNo) {
		del(myNo,friendNo);
		del(friendNo,myNo);
	}
	
	//친구 삭제 명령 입력문
	private void del(String myNo, String friendNo) {
		String delNo = String.format(
				"delete from %s where myUserNo= %s and friendUserNo = %s"
				, Master_DB.DB_TABLE_LIST, myNo, friendNo);
		update(delNo);
		close();
	}

	

}

package com.MangoChat.Invite;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.MangoChat.MasterClass.Master_DA;

public class I_Dao extends Master_DA {

	public ArrayList<I_Dto> InviteList(String myUserNo) { // 알림창 조회 출력할떄
		ArrayList<I_Dto> inviteList = new ArrayList<I_Dto>();
		String sql = String.format("SELECT * FROM %s WHERE freindUserNo = %s", DB_TABLE_INVITE, myUserNo);
		try {
			ResultSet rs = super.Query(sql);
			while (rs.next()) {
				if (rs.getInt("value") == 0) {
					inviteList.add(new I_Dto(rs.getString("no"), rs.getString("myUserNo"), rs.getString("friendUserNo"),
							rs.getString("value")));
				} else if (rs.getInt("value") == 1) {
					inviteList.add(new I_Dto(rs.getString("no"), rs.getString("myUserNo"), rs.getString("friendUserNo"),
							rs.getString("roomNo"), rs.getString("value")));
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return inviteList;
	}

	public void friendInvite(I_Dto invite) { // 친구추가 메세지 보내기
		String sql = String.format("INSERT INTO %s(myUserNo,freindUserNo,value)VALUES(%s,%s,%s)", DB_TABLE_INVITE,
				invite.myUserNo, invite.friendUserNo, invite.value);
		update(sql);
		close();
	}
	
	
	
	public void roomInvite(I_Dto invite, String roomNo) { // 채팅방 초대 메세지 보내기
		String sql = String.format("INSERT INTO %s(myUserNo,freindUserNo,roomNo,value)VALUES(%s,%s,%s,%s)",
				DB_TABLE_INVITE, invite.myUserNo, invite.friendUserNo, roomNo, invite.value);
		update(sql);
		close();
	}

	
	public void invite(String myUserNo,String inviteNo) { // 수락 누를시 작동
		I_Dto invite = inviteInfo(inviteNo);
		if(invite.value.equals("0")) { // 친구추가
			Add(invite.myUserNo,invite.friendUserNo); 
			Add(invite.friendUserNo,invite.myUserNo);
		}else if(invite.value.equals("1")) {//방초대
		String	sql = String.format("INSERT INTO %s(userNo,roomNo) values (%s,%s)", DB_TABLE_JOIN, myUserNo,
					invite.roomNo);
		update(sql);
		}
		close();
		inviteDel(inviteNo);
	}
	
	
	//친구추가 명령문
	private void Add(String myUserNo, String friendUserNo) {
		String AddNo = String.format("insert into %s(myUserNo, friendUserNo) values(%s, %s)"
				, DB_TABLE_LIST, myUserNo, friendUserNo);
		update(AddNo);
		close();
		// 체크박스 활용해서 추가기능 만들면 되요~~
		// 체크박스 테이블에 들어가있는거 삭제 후 프렌드리스트 찐 테이플에 추가하는거 추가하면 됩니당~~
		// jsp 에서 신청받은 리스트 추가하는건 나중에 하면되요~~
		// 이 글은 10초뒤 자동으로 삭제는 안되니까 알아서 삭제 해주세요~~
	}

	
	
	//알람을 없애야할때 사용
	public void inviteDel(String inviteNo) {
		String delSql = String.format("DELETE FROM %s WHERE no = %s", DB_TABLE_INVITE, inviteNo);
		update(delSql);
		close();
	}

	
// 알람들의 정보값을 불러오기
	private I_Dto inviteInfo(String inviteNo) {
		I_Dto invite = null;
		String sql = String.format("SELECT * FROM %s WHERE no = %s",DB_TABLE_INVITE,inviteNo);
		try {
			ResultSet rs = Query(sql);
			rs.next();
			int value = rs.getInt("value");
			if (value== 0) { // 친구추가 불러오기
			invite = new I_Dto(rs.getString("no"),rs.getString("myUserNo"),rs.getString("friendUserNo"),rs.getString("value"));
			} else if(value == 1) { // 방초대 불러오기
				invite = new I_Dto(rs.getString("no"),rs.getString("myUserNo"),rs.getString("friendUserNo"),rs.getString("roomNo"),rs.getString("value"));
			}
		}catch (SQLException e) {
			System.out.println(sql);
			e.printStackTrace();
		}finally {
			close();
		}
		
		return invite;
	}

}
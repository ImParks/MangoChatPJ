package LoginDB;

public class L_Dto {

	public String user_no;
	public String id;
	public String pw;
	public String user_name;
	public String user_tag;

	public L_Dto(String id, String pw) {
		this.id = id;
		this.pw = pw;
	}

	public L_Dto(String no, String id, String pw, String name, String name_num) {
		this.user_no = no;
		this.id = id;
		this.pw = pw;
		this.user_name = name;
		this.user_tag = name_num;
	}

	public L_Dto(String id, String pw, String name) {
		this.id = id;
		this.pw = pw;
		this.user_name = name;
	}

}

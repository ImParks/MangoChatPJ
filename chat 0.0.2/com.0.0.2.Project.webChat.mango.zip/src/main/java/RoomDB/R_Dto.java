package RoomDB;

public class R_Dto {
	String user_name;
	String user_tag;
	String chat;
	String time;
	
	R_Dto(String user_name, String user_tag, String chat, String time){
		this.user_name =  user_name;
		this.user_tag = user_tag;
		this.chat = chat;
		this.time = time;
	}
}

package RoomDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class R_Dao extends R_Db {

	private static String chat_no;
	private static Connection con = null;
	private static Statement st = null;
	private static ResultSet rs = null;
	private static HttpServletRequest request;
	private static HttpSession session;
	private static ArrayList<R_Dto> room_list;
	private static ArrayList<String> room_no;

	private static void start() {
		try {
			Class.forName(DB_LINK);
			con = DriverManager.getConnection(DB_URL, DB_ID, DB_PW);
			st = con.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void close() {
		try {
			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String session(HttpServletRequest request, String a) {
		session = request.getSession();
		String sess = session.getAttribute(a) + "";
		return sess;
	}
	
	public static void create(String name) {
		chatroom(name);
		String roomNo = roomNo();
		chatJoin(roomNo);
		
	}

	private static void chatroom(String name) { // 채팅방 정보 생성 <-- 첫번째
		String sql = String.format("INSERT INTO %s(room_name,room_stat,user_max)values('%s',0,2)", DB_TABLE, name);
		try {
			start();
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
	}

	private static String roomNo() {
		String sql = String.format("SELECT MAX(room_no) FROM %s",DB_TABLE);
		String re = null;
		try {
			start();
			rs = st.executeQuery(sql);
			rs.next();
			re = rs.getString("MAX(room_no)"); 
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return re;
	}
	
	private static void chatJoin(String no) { // 두번째
		String sql = String.format("INSERT INTO chatjoin(user_no,room_no)values(%s,%s)", session(request, "user_no"),
				no);
		try {
			start();
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
	}

	private static void createChat(String table_no) { // 채팅방 만들기 <-- 이거 맨 마지막에 해야함
		String sql = String.format("CREATE TABLE " + chat_no + " (" + "chat_no int primary key auto_increment"
				+ "id_no int" + "chat char(50)" + "time datetime not not null defalt now(),");
		try {
			start();
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
	}

}

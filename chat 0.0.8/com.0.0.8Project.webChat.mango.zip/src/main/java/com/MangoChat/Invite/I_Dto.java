package com.MangoChat.Invite;

public class I_Dto {

	public String no;
	public String myUserNo;
	public String freindUserNo;
	public String roomNo;
	public String value;
	
	public I_Dto(String no, String myUserNo, String freindUserNo, String roomNo, String value) {
		this.no = no;
		this.myUserNo = myUserNo;
		this.freindUserNo = freindUserNo;
		this.roomNo = roomNo;
		this.value = value;
	}

	public I_Dto(String no, String myUserNo, String freindUserNo, String value) {
		this.no = no;
		this.myUserNo = myUserNo;
		this.freindUserNo = freindUserNo;
		this.value = value;
	}

	public I_Dto(String myUserNo, String freindUserNo, String value) {
		this.myUserNo = myUserNo;
		this.freindUserNo = freindUserNo;
		this.value = value;
	}

	
	
	
	
}

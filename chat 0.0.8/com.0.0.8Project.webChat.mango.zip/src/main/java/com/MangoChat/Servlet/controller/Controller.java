package com.MangoChat.Servlet.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MangoChat.Invite.I_Dto;
import com.MangoChat.LoginDB.L_Dto;
import com.MangoChat.Servlet.Service;
import com.MangoChat.util.Util;

@WebServlet("/chat/*")
public class Controller extends HttpServlet {

	Service service;
	Util util;
	String nextPage;
	String id;
	String pw;
	String userName;
	String userTag;
	String myUserNo;
	String userNo;

	public void init() throws ServletException {
		service = new Service();
		util = new Util();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		request.setCharacterEncoding("UTF-8");
		String action = request.getPathInfo();
		if (action != null) {
			switch (action) {
			case "/signUp":
				nextPage = "/signUp.jsp";
				break;
			case "/signUp_proc": // 회원가입 작업실행
				// 아직 get 방식으로 정보를 받아옴
				id = String.format(request.getParameter("id")); 
				pw = String.format(request.getParameter("pw"));
				String pwRe = String.format(request.getParameter("pwRe"));
				userName = String.format(request.getParameter("name"));
				String regex = ".*[\\p{Punct}\\s].*";
				try {
					if (id.length() <= 0 || pw.length() <= 0 || pwRe.length() <= 0 || userName.length() <= 0) { // 입력한 글자수 조회
						nextPage = "/signUp.jsp?mag=null";
					} else if (id.matches(regex) || pw.matches(regex) || pwRe.matches(regex) // 글자 사이의 특수문자 있으면 안됌
							|| userName.matches(regex)) {
						nextPage = "/signUp.jsp?mag=*";
					} else if (!pw.equals(pwRe)) {
						nextPage = "/signUp.jsp?mag=pw"; //
					} else if (service.signUpIdCk(id)) {
						L_Dto join = new L_Dto(id, pw, userName);
						service.signUp(join);
						nextPage = "/login.jsp";
					} else {
						nextPage = "/signUp.jsp?mag=id";
					}
				} catch (NullPointerException e) {
					nextPage = "/signUp.jsp?mag=null";
				}
				break;
			case "/login_proc":
				id = String.format(request.getParameter("id"));
				pw = String.format(request.getParameter("pw"));
				if (service.idck(id, pw)) {
					L_Dto idPw = service.idPw(id, pw);
					session.setAttribute("userNo", idPw.userNo);
					session.setAttribute("userName", idPw.userName);
					session.setAttribute("userTag", idPw.userTag);
					nextPage = "/chat/home";
				} else {
					nextPage = "/chat/login";
				}
				break;
			case "/chatting":
				nextPage = "/chat/home";
				String chatContent = request.getParameter("chat");
				String roomNo = request.getParameter("roomNo");
				String userNo = (String) session.getAttribute("userNo");
				service.chatting(roomNo, chatContent, userNo);
				break;
			case "/home":
				nextPage = "/home.jsp";
//				request.setAttribute("roomNo", request.getParameter("roomNo"));
				break;
			case "/login":
				nextPage = "/login.jsp";
				break;
			case "/CreateRoom": // 방만들기
				nextPage = "/chat/home";
				String roomName = request.getParameter("roomName");
				String userMax = request.getParameter("userMax");
				userName = (String) session.getAttribute("userNo");
				service.create(userName, roomName, userMax);
				break;
			case "/roomInvite": // 채팅방 초대보내기
				nextPage = "/chat/home";
				myUserNo = (String) session.getAttribute("userNo");
				userName = request.getParameter("userName");
				userTag = request.getParameter("userTag");
				roomNo = request.getParameter("roomNo");
				userNo = util.userNo(userName, userTag);
				System.out.println("초대할사람"+userNo);
				//String userNo, String freindUserNo, String roomNo, String value
				if(userNo == null) {
					nextPage = "/home.jsp?mag=not";
				}else if(userNo != null && !userNo.equals(myUserNo) && util.userJoinCk(userNo,roomNo) && util.inviteCk(myUserNo,userNo,roomNo,"1")) {
				I_Dto dto = new I_Dto(myUserNo, userNo, "1");
				service.roomInvite(dto, roomNo);
				}else if(!util.inviteCk(myUserNo,userNo,roomNo,"1")) { 
					nextPage = "/home.jsp?mag=invite";
				}else if(userNo.equals(myUserNo)){
					nextPage = "/home.jsp?mag=myName";
				} else if (!util.userJoinCk(userNo,roomNo)){
					nextPage = "/home.jsp?mag=join";
				}
				System.out.println("다음페이지"+nextPage);
				break;
			case "/freindInvite": // 친추요청 보내기

				break;
			case "/Invite":
				nextPage = "/chat/home";
				String inviteNo = request.getParameter("inviteNo");
				myUserNo = (String) session.getAttribute("userNo");
				String check = request.getParameter("check");
				if (check.equals("수락")) {
					service.invite(myUserNo, inviteNo);
				} else {//거절
					service.inviteDel(inviteNo);
				}
				break;
			}

			RequestDispatcher n = request.getRequestDispatcher(nextPage);
			n.forward(request, response);

		}

	}
}
